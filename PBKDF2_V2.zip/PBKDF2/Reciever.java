import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Scanner;

public class Reciever {
    public static byte[] reciever(byte[] salt_recebido) throws NoSuchAlgorithmException {

        //valores para a criação da chave intermediária
        int numDeCodigos = 1024;
        int tamanhoChave = 256;


        //salt
        byte[] salt = new byte[0];
        salt = salt_recebido;

        System.out.println("O salt gerado pelo emissor da mensagem é: " +  Arrays.toString(salt_recebido));

        //Palavra passe fornecida pelo utilizador
        //Input da passe
        Scanner scanner = new Scanner(System.in);
        System.out.println("Qual a palavra passe acordada para a comunicação");
        String passe = scanner.nextLine();

        //Escolha da Cifra

        int escolha;
        Scanner scanner1 = new Scanner(System.in);
        while (true) {
            System.out.println("Qual a cifra que pretende utilizar?");
            System.out.println("1 -> SHA-1");
            System.out.println("2 -> SHA-256");
            escolha = scanner1.nextInt();
            if (escolha == 1 || escolha == 2) {
                break; // Break the loop if the input is valid (1 or 2)
            } else {
                System.out.println("Escolha inválida. Por favor, insira 1 ou 2.");
            }
        }

        //Separação da palavra
        char[] passeSeparada = passe.toCharArray();

        switch(escolha){
            case 1:
                MessageDigest sha1 = MessageDigest.getInstance("SHA-1");

                //passar a palavra-passe para bytes
                byte[] passeSeparadaBytes = new byte[passeSeparada.length]; // CRiação do array que vai guardar a passe SEparada em Bytes
                for(int i = 0; i < passeSeparadaBytes.length; i++){ // ciclo que corre a passeSEparada um a um e um a um
                    passeSeparadaBytes[i] = (byte) passeSeparada[i];  // vai mete-los na passeSeparadaBytes na mesma ordem mas a versão byte
                }                                                     //faz um cast pata o tipo Byte
                System.out.println(Arrays.toString(passeSeparadaBytes));

                byte[] chaveIntermediaria = PBKDF2.pbkdf2SHA1(passeSeparada, salt, numDeCodigos, tamanhoChave);

                // Imprimir a chave intermediária (para fins de demonstração)
                if (chaveIntermediaria != null) {
                    System.out.println("Chave Intermediária: " + Arrays.toString(chaveIntermediaria));
                }

                //Converter a chave intermediária de Byte[] para Char[]
                assert chaveIntermediaria != null;
                char[] chaveIntermediariaChars = new String(chaveIntermediaria).toCharArray();


                // CHAVE FINAL, FINALMENTE
                // Each element in the array represents a signed byte value ranging from -128 to 127.
                byte[] chaveFinal = PBKDF2.finalKeySHA1(chaveIntermediariaChars, salt);
                if(chaveFinal != null){
                    System.out.println("A chave Final é: " + Arrays.toString(chaveFinal));
                }
                break;

            case 2:
                MessageDigest sha256 = MessageDigest.getInstance("SHA-256");

                //passar a palavra-passe para bytes
                byte[] passeSeparadaBytes3 = new byte[passeSeparada.length]; // CRiação do array que vai guardar a passeSEparada em Bytes
                for(int i = 0; i < passeSeparadaBytes3.length; i++){ // ciclo que corre a passeSEparada um a um e um a um
                    passeSeparadaBytes3[i] = (byte) passeSeparada[i];  // vai mete-los na passeSeparadaBytes na mesma ordem mas a versão byte
                }                                                     //faz um cast pata o tipo Byte
                System.out.println(Arrays.toString(passeSeparadaBytes3));

                byte[] chaveIntermediaria3 = PBKDF2.pbkdf2SHA256(passeSeparada, salt, numDeCodigos, tamanhoChave);

                // Imprimir a chave intermediária (para fins de demonstração)
                if (chaveIntermediaria3 != null) {
                    System.out.println("Chave Intermediária: " + Arrays.toString(chaveIntermediaria3));
                }

                //Converter a chave intermediária de Byte[] para Char[]
                char[] chaveIntermediariaChars3 = new String(chaveIntermediaria3).toCharArray();


                // CHAVE FINAL, FINALMENTE
                // Each element in the array represents a signed byte value ranging from -128 to 127.
                byte[] chaveFinal3 = PBKDF2.finalKeySHA256(chaveIntermediariaChars3, salt);
                if(chaveFinal3 != null){
                    System.out.println("A chave Final é: " + Arrays.toString(chaveFinal3));
                }
                break;

        }
        return null;
    }

}